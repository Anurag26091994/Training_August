package com.yash.java8.problem7;

public interface Calculate {
	public double calculate(double principal, double rate, double time, double emi);
}
