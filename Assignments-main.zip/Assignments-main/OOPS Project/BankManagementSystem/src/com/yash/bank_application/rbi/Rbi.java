package com.yash.bank_application.rbi;

public interface Rbi {

	public void createAccount();
	public void displayAllDetails();
	public void depositeMoney();
	public void withdrawal();
	public void balanceCheck();
}
