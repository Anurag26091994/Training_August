package com.yash.ioc.Question3;

public class DrawShape {
	
	public static void main(String[] args) {
		
	}
}
