package com.yash.ioc.Question3;

public abstract class Shape {
	public abstract void draw(); 
}
