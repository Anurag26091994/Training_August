package com.yash.ioc.Question3;

public class Triangle extends Shape{


	public void draw() {
		System.out.println("display method executed from triangle ");
	}

}
