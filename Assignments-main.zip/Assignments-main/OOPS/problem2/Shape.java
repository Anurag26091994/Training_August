package com.yash.traning.opps.homeAssignemnt.problem2;

public interface Shape 
{
   void area();
  
}
